import java.util.Scanner;
public class MyClass {
    public static void main(String args[]) {
      
    Scanner sc = new Scanner(System.in);
    
    int n = 0;
    int x = 0;
    int a = 0;
    int b = 0;
    int c = 0;
    int d = 0;
    
    n = sc.nextInt();
    
    for(int i=1; i<=n; i++){
      
    x = sc.nextInt();
        c = x / 2;
        d = 0;
        
    for(b =1; b<=c; b++){
    
    if(x % b == 0)
        d = d + b;
    }
    if(d == x){
        	System.out.printf("%d eh perfeito.\n", x);
    }else {
        	System.out.printf("%d nao eh perfeito.\n", x);
            }
        }
    }
}
